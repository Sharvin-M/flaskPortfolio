# Personal Portfolio Web Application

Built using HTML and Tailwind CSS for frontend and Flask + SQLite3 for backend. 

Used Flask to route pages and add an interactive contacts page for potential employers to
contact me. The info is then stored in a SQLite3 databse. 

Reasoning behind the stack:

Flask and SQlite were used because this is an extrmley lightweight appplication.
HTMl and CSS are standard however I added Tailwind to make writing/organizing CSS easier.

